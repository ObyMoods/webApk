import os
from dotenv import load_dotenv

load_dotenv(".env")

MAX_BOT = int(os.getenv("MAX_BOT", "9999"))

DEVS = list(map(int, os.getenv("DEVS", "1680896327").split()))

API_ID = int(os.getenv("API_ID", "34802264"))

API_HASH = os.getenv("API_HASH", "7a01d54a9d668a26bf82c60f5f6bc891")

BOT_TOKEN = os.getenv("BOT_TOKEN", "8868021522:AAF0e6myRwZVE3pDmS_MV8FEaz_0gDXgx_Y")

OWNER_ID = int(os.getenv("OWNER_ID", "8219929978"))

BLACKLIST_CHAT = list(map(int, os.getenv("BLACKLIST_CHAT", "-1003878688914").split()))

RMBG_API = os.getenv("RMBG_API", "Y8mKMpDEsaZsvRikj4xk8xRR")

MONGO_URL = os.getenv("MONGO_URL", "mongodb+srv://KavCryz_db_user:Kafadillah111222@cluster0.lp4skn6.mongodb.net/?appName=Cluster0")

LOGS_MAKER_UBOT = int(os.getenv("LOGS_MAKER_UBOT", "-1003878688914"))