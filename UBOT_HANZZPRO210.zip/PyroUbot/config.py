import os
from dotenv import load_dotenv

load_dotenv(".env")

MAX_BOT = int(os.getenv("MAX_BOT", "999"))

DEVS = list(map(int, os.getenv("DEVS", "7467197361").split()))

API_ID = int(os.getenv("API_ID", "30878155"))

API_HASH = os.getenv("API_HASH", "a0824fd6facff31c2cb1967e87c76b38")

BOT_TOKEN = os.getenv("BOT_TOKEN", "8746373867:AAFMclcPhBNuGmi29tSOrvBvIdOJFyRlmX8")

OWNER_ID = int(os.getenv("OWNER_ID", "8272883006"))

BLACKLIST_CHAT = list(map(int, os.getenv("BLACKLIST_CHAT", "-1002886184276").split()))

RMBG_API = os.getenv("RMBG_API", "a6qxsmMJ3CsNo7HyxuKGsP1o")

MONGO_URL = os.getenv("MONGO_URL", "mongodb+srv://yogzganz3_db_user:dtfhmjej7Io@cluster0.imkgdds.mongodb.net/?appName=Cluster0")

LOGS_MAKER_UBOT = int(os.getenv("LOGS_MAKER_UBOT", "7467197361"))
